package Assignment3;

//Node2 class for doubly linked list
class Node2
{
    int data;
    Node2 prev;
    Node2 next;

    public Node2(int data)
    {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

//DoublyLinkedList2 class
class DoublyLinkedList2
{
    Node2 head;
    Node2 tail;

    public DoublyLinkedList2()
    {
        this.head = null;
        this.tail = null;
    }

    // Method to add a node at the end of the list
    public void addNode(int data)
    {
        Node2 newNode = new Node2(data);
        if (head == null)
        {
            head = tail = newNode;
        } else
        {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    // Method to traverse the list forward
    public void traverseForward()
    {
        Node2 current = head;
        while (current != null)
        {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    // Method to traverse the list backward
    public void traverseBackward()
    {
        Node2 current = tail;
        while (current != null)
        {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
}

public class P07
{
    public static void main(String[] args)
    {
        DoublyLinkedList2 dll = new DoublyLinkedList2();
        dll.addNode(1);
        dll.addNode(2);
        dll.addNode(3);
        dll.addNode(4);

        System.out.println("Forward traversal:");
        dll.traverseForward();

        System.out.println("Backward traversal:");
        dll.traverseBackward();
    }
}
