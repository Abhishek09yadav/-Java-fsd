package Assignment3;
import java.util.Arrays;

public class P02 {
    public static void main(String[] args) {
        int[] arr = {7, 5, 9, 3, 2, 8, 1, 6, 4, 0};
        int n = arr.length;
        if (n < 4) {
            System.out.println("The array does not contain enough elements.");
            return;
        }
        int fourthSmallestElement = findFourthSmallest(arr);
        System.out.println("The fourth smallest element is: " + fourthSmallestElement);
    }

    public static int findFourthSmallest(int[] arr) {
        Arrays.sort(arr);
        return arr[3];
    }
}
