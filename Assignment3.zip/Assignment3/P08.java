package Assignment3;
public class P08 {
    private Node top;

    private static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public P08() {
        this.top = null;
    }

    public void push(int element) {
        Node newNode = new Node(element);
        if (top == null) {
            top = newNode;
        } else {
            newNode.next = top;
            top = newNode;
        }
        System.out.println(element + " pushed to stack");
    }

    public int pop() {
        if (top == null) {
            System.out.println("Stack is empty");
            return Integer.MIN_VALUE;
        } else {
            int popped = top.data;
            top = top.next;
            return popped;
        }
    }

    public int peek() {
        if (top == null) {
            System.out.println("Stack is empty");
            return Integer.MIN_VALUE;
        } else {
            return top.data;
        }
    }

    public static void main(String[] args) {
        P08 stack = new P08();

        stack.push(10);
        stack.push(20);
        stack.push(30);

        System.out.println(stack.pop() + " popped from stack");

        System.out.println("Top element is " + stack.peek());
    }
}
