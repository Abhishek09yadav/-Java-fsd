package Assignment3;
//Write a program in Java to insert and remove elements in a queue

public class P09 {
    private Node front, rear;

    private static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public P09() {
        this.front = this.rear = null;
    }

    // Method to add an element to the queue
    public void enqueue(int element) {
        Node newNode = new Node(element);
        if (rear == null) {
            front = rear = newNode;
            System.out.println(element + " added to queue");
            return;
        }
        rear.next = newNode;
        rear = newNode;
        System.out.println(element + " added to queue");
    }

    // Method to remove an element from the queue
    public int dequeue() {
        if (front == null) {
            System.out.println("Queue is empty");
            return Integer.MIN_VALUE;
        }
        int removed = front.data;
        front = front.next;
        if (front == null) {
            rear = null;
        }
        return removed;
    }

    public static void main(String[] args) {
        P09 queue = new P09();

        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);

        System.out.println(queue.dequeue() + " removed from queue");
        System.out.println(queue.dequeue() + " removed from queue");
    }
}
