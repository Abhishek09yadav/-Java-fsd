package Assignment3;

// * Write a program in Java to delete the first occurrence of a key in a singly linked list
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class P05 {
    Node head;

    public void deleteKey(int key) {
        Node temp = head, prev = null;

        if (temp != null && temp.data == key) {
            head = temp.next; // Changed head
            return;
        }
        while (temp != null && temp.data != key) {

            prev = temp;
            temp = temp.next;

        }
        if (temp == null) return;

        prev.next = temp.next;
    }

    public static void main(String[] args) {
        P05 llist = new P05();
        llist.push(7);
        llist.push(1);
        llist.push(3);
        llist.push(2);
        System.out.println("\nCreated Linked list is:");
        llist.printList();

        int key = 1; // key to be deleted
        llist.deleteKey(key); // Delete first occurrence of 1

        System.out.println("\nLinked List after Deletion of 1:");
        llist.printList();
    }

    private void printList() {
        Node tnode = head;
        while (tnode != null) {
            System.out.print(tnode.data + " ");
            tnode = tnode.next;
        }
    }

    private void push(int new_data) {
        Node newNode = new Node(new_data);
        newNode.next = head;
        head = newNode;

    }
}