package Assignment1;

public class P01 {
    public static void main(String[] args) {
        // Implicit casting (int to double)
        int myInt = 10;
        double myDouble = myInt;
        System.out.println("Implicit casting: " + myDouble);

        // Explicit casting (double to int)
        double anotherDouble = 15.5;
        int anotherInt = (int) anotherDouble;
        System.out.println("Explicit casting: " + anotherInt);
    }
}
