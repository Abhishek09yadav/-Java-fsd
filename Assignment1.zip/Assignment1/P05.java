package Assignment1;

import java.util.*;

public class P05 {
    public static void main(String[] args) {
        testList();
        testSet();
        testMap();
    }

    private static void testList() {
        System.out.println("Testing List implementation...");
        List<String> list = new ArrayList<>();
        list.add("apple");
        list.add("banana");
        list.add("orange");
        assert list.size() == 3;
        assert list.contains("banana");
        list.remove(1);
        assert list.size() == 2;
        assert list.get(0).equals("apple");
        assert list.get(1).equals("orange");
        System.out.println("List implementation passed tests.");
    }

    private static void testSet() {
        System.out.println("Testing Set implementation...");
        Set<Integer> set = new HashSet<>();
        set.add(1);
        set.add(2);
        set.add(3);
        set.add(2); // Duplicate, should be ignored
        assert set.size() == 3;
        assert set.contains(2);
        set.remove(3);
        assert set.size() == 2;
        assert set.contains(1);
        assert !set.contains(3);
        System.out.println("Set implementation passed tests.");
    }

    private static void testMap() {
        System.out.println("Testing Map implementation...");
        Map<String, Integer> map = new HashMap<>();
        map.put("apple", 1);
        map.put("banana", 2);
        map.put("orange", 3);
        assert map.size() == 3;
        assert map.get("banana") == 2;
        map.put("banana", 4); // Overwrite existing value
        assert map.get("banana") == 4;
        map.remove("orange");
        assert map.size() == 2;
        assert !map.containsKey("orange");
        System.out.println("Map implementation passed tests.");
    }
}