package Assignment1;

public class P03 {

    public static void greetUser() {
        System.out.println("Hello, user!");
    }

    public static int add(int a, int b) {
        return a + b;
    }

    public static String concatenateStrings(String str1, String str2) {
        return str1 + str2;
    }

    public static void main(String[] args) {
        // Calling a method with no parameters
        greetUser();

        // Calling a method with parameters
        int sum = add(3, 5);
        System.out.println("The sum is: " + sum);

        // Calling a method with a return value
        String concatenatedString = concatenateStrings("Hello, ", "world!");
        System.out.println("The concatenated string is: " + concatenatedString);

        // Verifying method implementation with assertions
        assert sum == 8 : "The sum of 3 and 5 should be 8";
        assert concatenatedString.equals("Hello, world!") : "The concatenated string should be 'Hello, world!'";
    }
}