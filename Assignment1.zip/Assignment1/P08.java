package Assignment1;

public class P08 {
    public static void main(String[] args) {
        // Create a string
        String str = "Hello, World!";
        System.out.println("Original String: " + str);

        // Convert string to StringBuffer
        StringBuffer strBuffer = new StringBuffer(str);
        System.out.println("StringBuffer: " + strBuffer);

        // Convert string to StringBuilder
        StringBuilder strBuilder = new StringBuilder(str);
        System.out.println("StringBuilder: " + strBuilder);
    }
}