import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class RestClientService {

    private final RestTemplate restTemplate;

    @Autowired
    public RestClientService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getDataFromService(String url) {
        return restTemplate.getForObject(url, String.class);
    }
}
