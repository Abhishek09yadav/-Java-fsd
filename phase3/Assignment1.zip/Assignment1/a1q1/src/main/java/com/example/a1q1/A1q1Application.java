package com.example.a1q1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A1q1Application {

	public static void main(String[] args) {
		SpringApplication.run(A1q1Application.class, args);
	}

}
