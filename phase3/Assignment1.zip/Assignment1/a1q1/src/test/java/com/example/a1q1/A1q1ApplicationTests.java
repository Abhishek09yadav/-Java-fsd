package com.example.a1q1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A1q1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
