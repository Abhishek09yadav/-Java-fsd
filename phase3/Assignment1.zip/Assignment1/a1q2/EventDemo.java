import javax.swing.*;
import java.awt.event.*;

public class EventDemo extends JFrame {

    private JButton button;

    public EventDemo() {
        // Set up the frame
        setTitle("Event Handling Demo");
        setSize(300, 200);
        setLocationRelativeTo(null);  // Center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());  // Set the layout manager

        // Create a button and add it to the frame
        button = new JButton("Click Me!");
        add(button);

        // Add default ActionListener
        button.addActionListener(new ActionListener() {
           
