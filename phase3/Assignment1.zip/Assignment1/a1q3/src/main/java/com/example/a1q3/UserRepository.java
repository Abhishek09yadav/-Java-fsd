package com.example.a1q3;

import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<User, Long> {
    // You can define custom query methods here
}