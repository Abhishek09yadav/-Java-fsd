package phase1FinalProject;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

class Camera {
    String brand;
    String model;
    double rentalAmountPerDay;
    boolean isRented;

    public Camera(String brand, String model, double rentalAmountPerDay) {
        this.brand = brand;
        this.model = model;
        this.rentalAmountPerDay = rentalAmountPerDay;
        this.isRented = false;
    }

    @Override
    public String toString() {
        return "Brand: " + brand + ", Model: " + model + ", Rental per day: $" + rentalAmountPerDay + ", Status: " + (isRented ? "Rented" : "Available");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Camera)) return false;
        Camera camera = (Camera) o;
        return brand.equals(camera.brand) && model.equals(camera.model);
    }

    @Override
    public int hashCode() {
        return (brand + model).hashCode();
    }
}

class UserWallet {
    double balance;

    public void addMoney(double amount) {
        balance += amount;
        System.out.println("Added $" + amount + " to wallet. Current balance: $" + balance);
    }

    public boolean deductMoney(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Deducted $" + amount + " from wallet. Remaining balance: $" + balance);
            return true;
        } else {
            System.out.println("Insufficient wallet amount.");
            return false;
        }
    }

    public void viewBalance() {
        System.out.println("Current wallet balance: $" + balance);
    }
}

class RentalService {
    List<Camera> cameras = new ArrayList<>();
    UserWallet wallet = new UserWallet();

    public boolean listCamera(String brand, String model, double rentalAmountPerDay) {
        Camera newCamera = new Camera(brand, model, rentalAmountPerDay);
        if (!cameras.contains(newCamera)) {
            cameras.add(newCamera);
            System.out.println("Camera listed successfully.");
            return true;
        } else {
            System.out.println("A camera with this brand and model is already listed.");
            return false;
        }
    }

    public void rentCamera(int cameraIndex) {
        if (cameraIndex >= 0 && cameraIndex < cameras.size()) {
            Camera camera = cameras.get(cameraIndex);
            if (!camera.isRented && wallet.deductMoney(camera.rentalAmountPerDay)) {
                camera.isRented = true;
                System.out.println("Camera rented successfully.");
            } else if (camera.isRented) {
                System.out.println("This camera is already rented.");
            }
        } else {
            System.out.println("Invalid camera selection.");
        }
    }

    public void displayCameras() {
        if (cameras.isEmpty()) {
            System.out.println("No Data Present at This Moment.");
        } else {
            for (int i = 0; i < cameras.size(); i++) {
                System.out.println((i + 1) + ". " + cameras.get(i).toString());
            }
        }
    }
}

public class CameraRentalApplication {
    private static boolean login(Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        return "admin".equals(username) && "admin123".equals(password);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to rentmycam.io - Please login");
        if (!login(scanner)) {
            System.out.println("Incorrect username or password.");
            return;
        }

        RentalService service = new RentalService();
        int choice = 0;

        do {
            try {
                System.out.println("\n1. List a Camera\n2. Rent a Camera\n3. Add/View Wallet\n4. View All Cameras\n5. Exit");
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline left-over

                switch (choice) {
                    case 1:
                        System.out.print("Enter brand: ");
                        String brand = scanner.nextLine();
                        System.out.print("Enter model: ");
                        String model = scanner.nextLine();
                        System.out.print("Enter rental amount per day: ");
                        double rentalAmountPerDay = scanner.nextDouble();
                        service.listCamera(brand, model, rentalAmountPerDay);
                        break;
                    case 2:
                        service.displayCameras();
                        System.out.print("Select a camera to rent (number): ");
                        if (scanner.hasNextInt()) {
                            int cameraIndex = scanner.nextInt() - 1;
                            service.rentCamera(cameraIndex);
                        } else {
                            System.out.println("Please enter a valid number for the camera selection.");
                            scanner.next();
                        }
                        break;
                    case 3:
                        System.out.println("1. Add Money\n2. View Balance");
                        int walletChoice = scanner.nextInt();
                        if (walletChoice == 1) {
                            System.out.print("Enter amount to add: ");
                            double amount = scanner.nextDouble();
                            service.wallet.addMoney(amount);
                        } else {
                            service.wallet.viewBalance();
                        }
                        break;
                    case 4:
                        service.displayCameras();
                        break;
                    case 5:
                        System.out.println("Exiting application. Thank you for using rentmycam.io!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please select a valid option.");
                }
            } catch (InputMismatchException ime) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
            }
        } while (choice != 5);

        scanner.close();
    }
}
