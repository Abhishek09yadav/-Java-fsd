import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class question4 extends HttpServlet {
  
    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        // Set the response content type to HTML
        response.setContentType("text/html");
        
        // Get the response writer
        PrintWriter out = response.getWriter();
        
        // Generate the HTML response
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head><title>Hello Servlet</title></head>");
        out.println("<body>");
        out.println("<h1>Hello, World!</h1>");
        out.println("</body></html>");
    }
}
