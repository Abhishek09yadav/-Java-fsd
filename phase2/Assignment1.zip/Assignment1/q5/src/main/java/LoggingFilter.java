import javax.servlet.*;
import java.io.IOException;

public class LoggingFilter implements Filter {

    private ServletContext context;

    public void init(FilterConfig fConfig) throws ServletException {
        this.context = fConfig.getServletContext();
        this.context.log("LoggingFilter initialized");
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        // Log the current servlet path.
        String path = ((HttpServletRequest) request).getServletPath();
        this.context.log("Requested Resource::" + path);
        
        // Pass the request back down the filter chain
        chain.doFilter(request, response);
    }

    public void destroy() {
        //close any resources here
    }
}
