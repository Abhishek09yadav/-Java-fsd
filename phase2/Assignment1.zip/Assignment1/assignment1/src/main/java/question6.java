import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class question6 extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve the visitCount cookie
        Cookie[] cookies = request.getCookies();
        int visitCount = 0;
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("visitCount")) {
                    visitCount = Integer.parseInt(cookie.getValue());
                }
            }
        }
        
        // Increment visit count
        visitCount++;
        
        // Create or update the visitCount cookie
        Cookie visitCountCookie = new Cookie("visitCount", Integer.toString(visitCount));
        visitCountCookie.setMaxAge(60*60*24); // Expires in 24 hours
        response.addCookie(visitCountCookie);

        // Display visit count
        out.println("<html><body>");
        out.println("<h2>You have visited this page " + visitCount + " times.</h2>");
        out.println("</body></html>");
    }
}
