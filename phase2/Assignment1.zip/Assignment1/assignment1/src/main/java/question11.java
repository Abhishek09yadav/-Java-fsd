import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class question11 extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Check credentials
        if ("admin".equals(username) && "admin".equals(password)) {
            HttpSession session = request.getSession();
            session.setAttribute("user", username);

            // Successful login
            out.println("<html><head><title>Welcome</title></head><body>");
            out.println("<h1>Welcome, " + username + "</h1>");
            out.println("<p>You are now logged in.</p>");
            out.println("<a href='logout'>Logout</a>");
            out.println("</body></html>");
        } else {
            // Failed login
            out.println("<html><head><title>Login Error</title></head><body>");
            out.println("<h1>Login Failed!</h1>");
            out.println("<p>Invalid username or password.</p>");
            out.println("<a href='login.html'>Try again</a>");
            out.println("</body></html>");
        }
    }
}
