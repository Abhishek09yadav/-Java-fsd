import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Extend HttpServlet class
public class question7 extends HttpServlet {

  public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {

      // Set response content type
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();

      // Create or retrieve session
      HttpSession session = request.getSession(true);
      
      // Write an HTML page
      out.println("<!DOCTYPE html>");
      out.println("<html>");
      out.println("<head><title>Session Tracking Demo</title></head>");
      out.println("<body>");

      if (session.isNew()) {
          out.println("<h1>Welcome, new visitor!</h1>");
      } else {
          out.println("<h1>Welcome back!</h1>");
      }
      
      // Rewrite URL with session ID
      String encodedURL = response.encodeURL("question7");
      out.println("<a href=\"" + encodedURL + "\">click me</a>");
      out.println("</body></html>");
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
      doGet(request, response);
  }
}
