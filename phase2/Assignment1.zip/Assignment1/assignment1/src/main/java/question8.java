import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Extend HttpServlet class
public class question8 extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Call doPost to handle the request
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Set response content type
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Attempt to read session info from hidden form field
        String sessionInfo = request.getParameter("sessionInfo");

        // Start HTML output
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head><title>Session Tracking Demo</title></head>");
        out.println("<body>");

        if (sessionInfo == null) {
            out.println("<h1>Welcome, new visitor!</h1>");
            sessionInfo = "Visited"; // Set session info to indicate the user has visited
        } else {
            out.println("<h1>Welcome back!</h1>");
        }

        // Form with hidden field for session tracking
        out.println("<form action='question8' method='POST'>");
        out.println("<input type='hidden' name='sessionInfo' value='" + sessionInfo + "'>");
        out.println("<input type='submit' value='Visit Again'>");
        out.println("</form>");

        out.println("</body></html>");
    }
}
