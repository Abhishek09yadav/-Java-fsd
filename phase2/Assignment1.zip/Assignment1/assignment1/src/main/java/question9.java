import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Extend HttpServlet class
public class question9 extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Set response content type
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Create or retrieve existing session
        HttpSession session = request.getSession(true);
        
        // Check if this is new comer on your web page.
        if (session.isNew()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head><title>Session Tracking Demo</title></head>");
            out.println("<body>");
            out.println("<h1>Welcome, new visitor!</h1>");
            out.println("</body></html>");
        } else {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head><title>Session Tracking Demo</title></head>");
            out.println("<body>");
            out.println("<h1>Welcome back!</h1>");
            out.println("</body></html>");
        }
    }
}
