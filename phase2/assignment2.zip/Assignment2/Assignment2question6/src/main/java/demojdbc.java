
import com.DbConnection;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DBOperations")
public class demojdbc extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        try (Connection conn = DbConnection.getConnection()) {
            switch (action) {
                case "insert":
                    insertRecord(conn, request);
                    break;
                case "update":
                    updateRecord(conn, request);
                    break;
                case "delete":
                    deleteRecord(conn, request);
                    break;
                default:
                    response.getWriter().append("Invalid action");
                    break;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().append("Error: " + e.getMessage());
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("GET method is supported now. Responding to your GET request.");
    }

    private void insertRecord(Connection conn, HttpServletRequest request) throws SQLException {
        String name = request.getParameter("name");
        String department = request.getParameter("department");
        double salary = Double.parseDouble(request.getParameter("salary"));
        String sql = "INSERT INTO Employees (name, department, salary) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setString(2, department);
            stmt.setDouble(3, salary);
            stmt.executeUpdate();
        }
    }

    private void updateRecord(Connection conn, HttpServletRequest request) throws SQLException {
        String name = request.getParameter("name");
        double newSalary = Double.parseDouble(request.getParameter("newSalary"));
        String sql = "UPDATE Employees SET salary = ? WHERE name = ?";
        try (PreparedStatement stmt = conn.prepareSta...
        stmt.setDouble(1, newSalary);
        stmt.setString(2, name);
        stmt.executeUpdate();
    }

    private void deleteRecord(Connection conn, HttpServletRequest request) throws SQLException {
        String name = request.getParameter("name");
        String sql = "DELETE FROM Employees WHERE name = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.executeUpdate();
        }
    }
}
