
//Writing a program in Java to verify implementation of arrays
public class P09 {
    public static void main(String[] args) {
        int[] numbers = {10, 20, 30, 40, 50};

        System.out.println("First element: " + numbers[0]);
        System.out.println("Third element: " + numbers[2]);

        numbers[3] = 45;
        System.out.println("Array after modification: ");
        printArray(numbers);

        int length = numbers.length;
        System.out.println("Length of the array: " + length);

        System.out.println("Array elements: ");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
    }

    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
