public class P02 {
    public int publicVar = 10;

    private int privateVar = 20;

    protected int protectedVar = 30;

    int defaultVar = 40;

    public static void main(String[] args) {
        P02 obj = new P02();

        // Accessing public variable
        System.out.println("Public variable: " + obj.publicVar);

        // Accessing private variable (only within the same class)
        System.out.println("Private variable: " + obj.privateVar);

        // Accessing protected variable
        System.out.println("Protected variable: " + obj.protectedVar);

        // Accessing default variable
        System.out.println("Default variable: " + obj.defaultVar);
    }

    // public method
    public void publicMethod() {
        System.out.println("Public method");
    }

    // private method
    private void privateMethod() {
        System.out.println("Private method");
    }

    // protected method
    protected void protectedMethod() {
        System.out.println("Protected method");
    }

    // default method
    void defaultMethod() {
        System.out.println("Default method");
    }
}

class AnotherClass {
    public static void main(String[] args) {
        P02 obj = new P02();

        System.out.println("Public variable: " + obj.publicVar);


        // Accessing protected variable
        System.out.println("Protected variable: " + obj.protectedVar);
//        System.out.println("Private variable: " + obj.privateVar);
        System.out.println("Default variable: " + obj.defaultVar);
    }
}