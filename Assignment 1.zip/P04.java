class Person {
    private String name;
    private int age;

    // Default constructor
    Person() {
        this.name = "Unknown";
        this.age = 0;
    }

    // Parameterized constructor
    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Copy constructor
    Person(Person other) {
        this.name = other.name;
        this.age = other.age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}

public class P04 {
    public static void main(String[] args) {
        // Creating an object using the default constructor
        Person person1 = new Person();
        System.out.println("Person 1: " + person1.getName() + ", " + person1.getAge());

        // Creating an object using the parameterized constructor
        Person person2 = new Person("John Doe", 30);
        System.out.println("Person 2: " + person2.getName() + ", " + person2.getAge());

        // Creating an object using the copy constructor
        Person person3 = new Person(person2);
        System.out.println("Person 3: " + person3.getName() + ", " + person3.getAge());
    }
}