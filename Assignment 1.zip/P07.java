
// Writing a program in Java to verify the implementation of inner classes
public class P07 {
    private int outerField = 10;

    // Non-static inner class
    private class InnerClass {
        private int innerField = 20;

        void displayInnerFields() {
            System.out.println("Inner Field: " + innerField);
            System.out.println("Outer Field: " + outerField);
        }
    }

    // Static nested class
    private static class StaticNestedClass {
        private int nestedField = 30;

        void displayNestedField() {
            // Cannot access non-static outerField directly
            // System.out.println("Outer Field: " + outerField); // Error

            System.out.println("Nested Field: " + nestedField);
        }
    }

    public void createInnerInstance() {
        InnerClass inner = new InnerClass();
        inner.displayInnerFields();
    }

    public static void createNestedInstance() {
        StaticNestedClass nested = new StaticNestedClass();
        nested.displayNestedField();
    }

    public static void main(String[] args) {
        P07 outer = new P07();
        outer.createInnerInstance();
        createNestedInstance();
    }
}