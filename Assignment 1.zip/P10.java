import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class P10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the regular expression: ");
        String regex = scanner.nextLine();

        System.out.print("Enter the number of test cases: ");
        int numTestCases = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        Pattern pattern = Pattern.compile(regex);

        for (int i = 0; i < numTestCases; i++) {
            System.out.print("Enter the test string: ");
            String testString = scanner.nextLine();

            Matcher matcher = pattern.matcher(testString);
            boolean matches = matcher.matches();

            System.out.println("Test case " + (i + 1) + ": " + (matches ? "Matches" : "Does not match"));
        }

        scanner.close();
    }
}
//output
/*Enter the regular expression: \d{3}-\d{3}-\d{4}
Enter the number of test cases: 3
Enter the test string: 123-456-7890
Test case 1: Matches
Enter the test string: 555-555-5555
Test case 2: Matches
Enter the test string: 123-45-6789
Test case 3: Does not match
 */