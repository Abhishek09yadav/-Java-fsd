import java.util.*;
//Writing a program in Java to verify implementations of maps
public class P06 {
    public static void main(String[] args) {
        System.out.println("Verifying HashMap implementation:");
        verifyMap(new HashMap<>());

        System.out.println("\nVerifying TreeMap implementation:");
        verifyMap(new TreeMap<>());

        System.out.println("\nVerifying LinkedHashMap implementation:");
        verifyMap(new LinkedHashMap<>());
    }

    public static <K, V> void verifyMap(Map<K, V> map) {
        // Add elements to the map
        map.put((K) "apple", (V) "red");
        map.put((K) "banana", (V) "yellow");
        map.put((K) "orange", (V) "orange");

        // Check size
        System.out.println("Size: " + map.size());

        // Check containsKey and containsValue
        System.out.println("Contains key 'apple': " + map.containsKey("apple"));
        System.out.println("Contains value 'red': " + map.containsValue("red"));

        // Get value for a key
        System.out.println("Value for key 'banana': " + map.get("banana"));

        // Remove an element
        map.remove("orange");
        System.out.println("Size after removing 'orange': " + map.size());

        // Iterate over the map
        System.out.println("Iterating over the map:");
        for (Map.Entry<K, V> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " => " + entry.getValue());
        }

        // Clear the map
        map.clear();
        System.out.println("Size after clearing the map: " + map.size());
    }
}