package Assignment2;


public class P04 {
    public static int divideNum(int dividend, int divisor) {
        return dividend / divisor;
    }

    public static void main(String[] args) {
        try {
            int result = divideNum(10, 0);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            e.printStackTrace();
        } finally {
            System.out.println("Finally block executed.");
        }
    }
}