package Assignment2;

//Write a program in Java to demonstrate synchronization
 class PrintingThread  extends Thread{
    private static final Object lock = new Object();
    private static int count = 0;


    public void run() {
        for (int i = 0; i < 10; i++) {
            synchronized (lock) {
                count++;
                System.out.println(Thread.currentThread().getName() + " Count: " + count);

            }
        }


    }

}
public class P03 {
    public static void main(String[] args) {
        Thread thread1 = new PrintingThread();
        Thread thread2 = new PrintingThread();
        thread1.start();
        thread2.start();
    }
}