package Assignment2;

import java.util.*;

public class P05 {
    public static void divide(int a, int b) throws CustomException{
        try {
            if(b == 0)
                throw new ArithmeticException("Divide by zero error");

        } catch (ArithmeticException e) {
            throw new CustomException("cannot divide by zero");
        }

    }
    public static void main(String[] args) {
        try {
            // Calling a method that throws a checked exception
            divide(10, 0);
        } catch (ArithmeticException e) {
            System.out.println("Caught ArithmeticException: " + e.getMessage());
        } catch (CustomException e) {
            System.out.println("Caught CustomException: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }
    }


}