package Assignment2;
//Write a program in Java to demonstrate exception handling

public class P06 {
    public static int divide(int numerator, int denominator) {
        return numerator / denominator;
    }
    public static void main(String[] args) {
        try {
            int result = divide(10, 0);
            System.out.println("The result is: " + result);
        } catch (ArithmeticException e) {

            System.out.println("An arithmetic error occurred: " + e.getMessage());
        } finally {

            System.out.println("The 'try catch' block is finished.");
        }

    }
}