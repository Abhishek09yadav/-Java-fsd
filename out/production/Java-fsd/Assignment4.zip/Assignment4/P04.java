package Assignment4;

import java.util.Scanner;

public class P04 {
    public static void selectionSort(int arr[]) {

        for (int i = 0; i < arr.length; i++) {
            int minindex = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[minindex] > arr[j]) {
                    minindex = j;
                }

            }
            int temp = arr[i];
            arr[i] = arr[minindex];
            arr[minindex] = temp;
        }

    }

    public static void main(String[] args) {
        int[] dataArray = {64, 25, 12, 22, 11};
        selectionSort(dataArray);

        System.out.println("Sorted array:");
        for (int i = 0; i < dataArray.length; i++) {
            System.out.print(dataArray[i] + " ");
        }
    }
}
