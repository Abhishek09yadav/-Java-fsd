package Assignment4;

//Writing a program in Java implementing the exponential search algorithm
import java.util.Scanner;

public class P03 {
    public static int exponentialSearch(int[] arr, int target) {

        int n = arr.length;
        if (arr[0] == target) {
            return 0;
        }
        int i = 1;
        while (i < n && arr[i] <= target) {
            i *= 2;
        }
        return binarySearch(arr, i / 2, Math.min(i, n - 1), target);
    }
    private static int binarySearch(int[] arr, int start, int end, int target){
        while (start <= end) {
            int mid = start + (end - start) / 2;
            if (arr[mid] == target) {
                return mid;
            }
            if (arr[mid] < target) {
                start = mid + 1;
            } else {
                end = mid - 1;
            }
        }

        return -1;
    }
    public static void main(String[] args) {
        int[] dataArray = {1, 3, 5, 7, 9, 11, 13, 15, 17, 19};
        int target = 11;
        int resultIndex = exponentialSearch(dataArray, target);

        if (resultIndex == -1) {
            System.out.println("Element is not present in the array.");
        } else {
            System.out.println("Element is present at index: " + resultIndex);
        }
    }

}